package execution;
import java.util.List;

public class Commands {
//
////	private List<Command> cmds;
////	public Commands(List<Command> cmds) {
////		this.cmds = cmds;
////	}
////	
////	public void run() {
////		for (Command command : cmds) {
////			command.run();
////		}
////		
////	}
//
//	
}
