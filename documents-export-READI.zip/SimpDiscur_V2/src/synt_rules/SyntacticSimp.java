package synt_rules;

import corpus_reader.Corpus;

public interface SyntacticSimp {
	public abstract Corpus simplify(Corpus corpus);
}
