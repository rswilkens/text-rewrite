package discur_rules;

public enum mention_type {
	noun, propernoun, pron_prs, pron_dem, pron_rel, det_poss, sym
}
