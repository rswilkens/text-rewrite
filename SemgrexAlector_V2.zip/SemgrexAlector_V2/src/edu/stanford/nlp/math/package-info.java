/**
 * Classes for Simple Math Functionality, such as Min, Max, WeightedAverage,
 * Scientific Notation, etc.
 *
 * @author Sepandar David Kamvar
 */
package edu.stanford.nlp.math;