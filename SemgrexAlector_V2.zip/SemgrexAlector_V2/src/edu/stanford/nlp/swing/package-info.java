/**
 * <body>
 * Collection of useful classes for building Swing GUIs.
 * </body>
 */
package edu.stanford.nlp.swing;