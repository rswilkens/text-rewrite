/**
 * A collection of useful thread-safe general-purpose utility classes.
 * Note that this is very much a work in progress, and may not work in all
 * cases.
 */
package edu.stanford.nlp.util.concurrent;