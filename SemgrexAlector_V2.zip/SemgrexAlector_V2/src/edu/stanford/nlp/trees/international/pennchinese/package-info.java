/**
 * Classes, and JFlex source file, for reading, tokenization and manipulation of Penn Chinese Treebank (CTB)
 * export-format files.
 * @author Roger Levy, Galen Andrew
 */
package edu.stanford.nlp.trees.international.pennchinese;