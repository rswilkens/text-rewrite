/**
 * A HeadFinder and TreebankLanguagePack for the
 * <a href="http://www.sfs.nphil.uni-tuebingen.de/en_tuebadz.shtml">The
 * T&uuml;bingen Treebank of Written German (T&uuml;Ba-D/Z)</a>,
 * a corpus of German Newspaper text.
 * @author Roger Levy
 */
package edu.stanford.nlp.trees.international.tuebadz;